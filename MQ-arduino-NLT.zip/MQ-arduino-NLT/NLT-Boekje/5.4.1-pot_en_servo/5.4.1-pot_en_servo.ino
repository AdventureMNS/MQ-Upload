#include <Servo.h>

Servo servo;

const int potPin = A0;
const int servoPin = 9;

void setup() {
  servo.attach(servoPin);
}

void loop() {
  int x = analogRead(potPin);  
  int angle = 180.0 * x / 1024.0;
  servo.write(angle);
  delay(10);
}