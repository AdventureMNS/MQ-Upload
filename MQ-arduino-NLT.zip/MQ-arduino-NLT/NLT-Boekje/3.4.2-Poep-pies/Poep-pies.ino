void setup() {
Serial.begin(9600);
}

void loop() {
Serial.println("pies");
delay(1000);
Serial.println("poep"); 
delay(1000);
}
