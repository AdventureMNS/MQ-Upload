int popmeter = 0;



void setup() {
pinMode(9, INPUT_PULLUP);
pinMode(2, OUTPUT);
pinMode(3, OUTPUT);
pinMode(4, OUTPUT);
pinMode(5, OUTPUT);
pinMode(6, OUTPUT);
pinMode(7, OUTPUT);
pinMode(8, OUTPUT);
Serial.begin(9600);
}

void loop() {
popmeter = analogRead(A0);
Serial.println(popmeter);
if (popmeter <= 145) {
  digitalWrite(2, HIGH);
  } else {
    //digitalWrite(2, LOW);
  }

if (popmeter >= 145 && popmeter <= 290) {
  digitalWrite(3, HIGH);
  } else {
    digitalWrite(3, LOW);
  }

if (popmeter >= 290 && popmeter <= 435) {
  digitalWrite(4, HIGH);
  } else {
    digitalWrite(4, LOW);
  }

if (popmeter >= 435 && popmeter <= 580) {
  digitalWrite(5, HIGH);
  } else {
    digitalWrite(5, LOW);
  }

if (popmeter >= 589 && popmeter <= 734) {
  digitalWrite(6, HIGH);
  } else {
    digitalWrite(6, LOW);
  }

if (popmeter >= 734 && popmeter <= 879) {
  digitalWrite(7, HIGH);
  } else {
    digitalWrite(7, LOW);
  }

if (popmeter >= 879) {
  digitalWrite(8, HIGH);
  } else {
    //digitalWrite(8, LOW);
  }
}
