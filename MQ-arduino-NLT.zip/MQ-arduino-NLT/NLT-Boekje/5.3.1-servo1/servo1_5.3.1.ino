#include <Servo.h>

Servo mijnServo;

void setup() {
  mijnServo.attach(9);
}

void loop() {
  // Snel heen
  mijnServo.write(180);
  delay(500);

  // Traag terug
  for (int hoek = 180; hoek >= 0; hoek--) {
    mijnServo.write(hoek);
    delay(20);
  }
}