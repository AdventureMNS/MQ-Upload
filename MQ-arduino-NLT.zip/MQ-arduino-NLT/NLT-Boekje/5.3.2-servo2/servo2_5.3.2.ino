#include <Servo.h>

Servo mijnServo;

void setup() {
  mijnServo.attach(9);
}

void loop() {
  for (int keer = 0; keer < 10; keer++) {
    mijnServo.write(180); 
    delay(500);

    for (int hoek = 180; hoek >= 0; hoek--) {
      mijnServo.write(hoek); 
      delay(20);
    }
  }

  delay(5000); 
}