const int potPin = A0;
const int buttonPin = 2;
const int ledPin = LED_BUILTIN;

int drempel = 500;
bool vorigeKnop = HIGH;
unsigned long laatsteDruk = 0;

void setup() {
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(ledPin, OUTPUT);
}

void loop() {
  bool knop = digitalRead(buttonPin);


  if (vorigeKnop == HIGH && knop == LOW &&
      millis() - laatsteDruk > 50) {
    drempel = analogRead(potPin);
    laatsteDruk = millis();
  }

  int potWaarde = analogRead(potPin);
  digitalWrite(ledPin, potWaarde >= drempel ? HIGH : LOW);

  vorigeKnop = knop;
}