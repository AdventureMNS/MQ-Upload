const int buttonPin1 = 2; 
const int buttonPin2 = 3; 


int buttonState1 = 0; 
int buttonState2 = 0; 

void setup() {
  pinMode(buttonPin1, INPUT_PULLUP);
  pinMode(buttonPin2, INPUT_PULLUP);
    Serial.begin(115200);
}


void loop() {

 buttonState1 = digitalRead(buttonPin1);
 buttonState2 = digitalRead(buttonPin2);

  if (buttonState1 == LOW) {
    Serial.println("Hallo");
    delay(1000);
  }
  if (buttonState2 == LOW) {
   Serial.println("Doei");
     delay(1000);
  }
}
