void setup() {
  pinMode(2, OUTPUT);


  for (int count = 10; count > 0; count--) {
    for (int i = 0; i < count; i++) {
      digitalWrite(2, HIGH); 
      delay(100);             
      digitalWrite(2, LOW);  
      delay(100);             
    }
    delay(1000);
  }
}

void loop() {
}
