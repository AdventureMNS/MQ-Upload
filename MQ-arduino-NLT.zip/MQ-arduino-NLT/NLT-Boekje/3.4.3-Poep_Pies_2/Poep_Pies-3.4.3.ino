int knop = 0;

void setup() {
  Serial.begin(9600);
  pinMode(2, INPUT_PULLUP);
}

void loop() {
  
  knop = digitalRead(2);

  if (knop == LOW) {
    Serial.println("vegen");
    delay(1000);
  } else {
    Serial.println("pies");
    delay(1000);
  }

  knop = digitalRead(2);

  if (knop == LOW) {
    Serial.println("vegen");
    delay(1000);
  } else {
    Serial.println("poep");
    delay(1000);
  }
}